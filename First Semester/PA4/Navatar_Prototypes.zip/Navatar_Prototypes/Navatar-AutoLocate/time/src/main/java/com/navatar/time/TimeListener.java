package com.navatar.time;

public interface TimeListener {

	public void onClockSynced(long offset);
}
