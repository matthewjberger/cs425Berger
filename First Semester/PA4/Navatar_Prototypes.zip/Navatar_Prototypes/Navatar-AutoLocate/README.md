[![License MIT](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/humanpluslab/Navatar/blob/master/license.md)
# Navatar
Low cost Indoor navigation system for people who are blind
