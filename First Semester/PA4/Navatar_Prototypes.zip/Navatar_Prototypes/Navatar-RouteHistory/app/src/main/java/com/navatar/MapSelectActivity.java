package com.navatar;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.navatar.maps.MapService;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MapSelectActivity extends Activity {
  private Spinner mapSpinner,campusSpinner;
  private TextView mapSelectTextView;
  private ArrayAdapter<String> mapArrayAdapter,campusArrayAdapter;
  private ArrayList<String> maplist;
  private MapService mapService;
  private Intent mapIntent;
  private PendingIntent pendingIntent;
  public static boolean ActivityDestryoed;

  // Get user location
  private Button b;
  private TextView t;
  private LocationManager locationManager;
  private LocationListener listener;
  private double LocLat;
  private double LocLong;

  @Override
  protected void onDestroy() {

      super.onDestroy();
      if(mapService!=null)
       unbindService(mMapConnection);
      if(pendingIntent!=null)
          pendingIntent.cancel();
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setTitle("Welcome to Navatar");
    setContentView(R.layout.map_select);


    mapIntent= new Intent(this, MapService.class);

    campusSpinner = (Spinner)findViewById(R.id.campusSpinner);

    campusArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new ArrayList<String>());
    campusArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

    ArrayList<String> campuslist = new ArrayList<String>();

    try {
      // Get user location
      t = (TextView) findViewById(R.id.textView);
      b = (Button) findViewById(R.id.button);

      locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

      listener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
          t.append("\n Received location");
          LocLat = location.getLatitude();
          LocLong = location.getLongitude();

          ////////////////////////////////////////
          // Throw lat and long into function which returns campus selection index/name if user is
          // within bounds.
          double UNRMinLat =39.536837;
          double UNRMaxLat =39.550971;
          double UNRMinLong =-119.822549;
          double UNRMaxLong =-119.809963;

          // Scrugham eng mines prototype location check
          if(LocLat > UNRMinLat  && LocLat < UNRMaxLat &&
                  LocLong > UNRMinLong && LocLong < UNRMaxLong)
          {
            t.append("\n AT UNR" + LocLat + " " + LocLong);
            campusSpinner.setSelection(1);
          }
          else
          {
            t.append("\n " + LocLat + " " + LocLong);
          }
          ////////////////////////////////////////
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {
          t.append("\n GPS enabled");
        }

        @Override
        public void onProviderDisabled(String s) {
          t.append("\n GPS disabled");
          Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
          startActivity(i);
        }
      };

      configure_button();

      // Campus select
      String[] campusNames = getAssets().list("maps");

      campuslist.add("Select a campus");
      for (int i=0;i<campusNames.length;i++){
        Log.d("Campus loaded", campusNames[i]);
        campuslist.add(campusNames[i].replaceAll("_"," "));
      }

    } catch (IOException e) {
      e.printStackTrace();
    }

    campusArrayAdapter.addAll(campuslist);
    campusSpinner.setAdapter(campusArrayAdapter);
    campusSpinner.setOnItemSelectedListener(campusSpinnerSelected);
    maplist = new ArrayList<String>();
    maplist.add(0,"Select Building");
    mapArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            maplist);
    startService(mapIntent);
    bindService(mapIntent, mMapConnection, BIND_AUTO_CREATE);
  }

  @Override
  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    switch (requestCode){
      case 10:
        configure_button();
        break;
      default:
        break;
    }
  }

  void configure_button(){
    // First check for permissions
    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}
                ,10);
        t.append("\n Location permission denied");
      }
      return;
    }
    // Only executes if permissions granted
    t.append("\n Location permission granted");
    b.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        //noinspection MissingPermission
        locationManager.requestLocationUpdates("gps", 5000, 0, listener);
        t.append("\n Requested location");
      }
    });
  }

  @Override
  protected void onResume(){
    super.onResume();

  }

  public OnItemSelectedListener campusSpinnerSelected = new OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
      if (position != 0) {
        String campusName = campusSpinner.getSelectedItem().toString();
        Log.d("Campus Select", campusSpinner.getSelectedItem().toString());
        campusName=campusName.replaceAll(" ","_");
        setContentView(R.layout.map_select_new);
        setTitle("Select the building");
        mapSelectTextView = (TextView)findViewById(R.id.tvmapselect);
        mapSpinner = (Spinner) findViewById(R.id.mapSpinner);


        mapSpinner.setAdapter(mapArrayAdapter);
        mapSpinner.setOnItemSelectedListener(mapSpinnerItemSelected);
        mapArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mapIntent.putExtra("path",campusName);
        Intent defaultIntent = new Intent();
        pendingIntent = MapSelectActivity.this.createPendingResult(1,defaultIntent,PendingIntent.FLAG_ONE_SHOT);
        mapIntent.putExtra("pendingIntent",pendingIntent);
        startService(mapIntent);
        bindService(mapIntent, mMapConnection, BIND_AUTO_CREATE);
      }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
   };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        maplist.clear();
        maplist.add("Select a building");
        if(data.hasExtra("maps"))
           maplist.addAll((ArrayList<String>) data.getSerializableExtra("maps"));

        ////////////////////////////////////////
        // Throw lat and long into function which returns building selection index/name if user is
        // within bounds.
        double ScrugMinLat =39.539465;
        double ScrugMaxLat =39.540015;
        double ScrugMinLong =-119.814085;
        double ScrugMaxLong =-119.812982;

        // Scrugham eng mines prototype location check
        if(LocLat > ScrugMinLat  && LocLat < ScrugMaxLat &&
                LocLong > ScrugMinLong && LocLong < ScrugMaxLong)
        {
          t.append("\n AT SCRUGHAM" + LocLat + " " + LocLong);
          mapSpinner.setSelection(3);
        }
        ////////////////////////////////////////////

        pendingIntent = null;
    }

    OnItemSelectedListener mapSpinnerItemSelected = new OnItemSelectedListener() {
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
      if (position != 0) {
        mapService.setActiveMap(position - 1);
        Intent intent = new Intent(MapSelectActivity.this, NavigationSelectionActivity.class);
        startActivity(intent);
      }
    }
    public void onNothingSelected(AdapterView<?> arg0) {}
  };


    /** Defines callback for service binding, passed to bindService() */
  private ServiceConnection mMapConnection = new ServiceConnection() {
    @Override
    public void onServiceConnected(ComponentName className, IBinder service) {
      MapService.MapBinder binder = (MapService.MapBinder) service;
      mapService = binder.getService();
    }
    @Override
    public void onServiceDisconnected(ComponentName name) {
      mapService = null;
    }
  };

  public void navHistory(View view) {
    Intent intent = new Intent(MapSelectActivity.this, NavigationHistoryActivity.class);
    startActivity(intent);
  }

}
